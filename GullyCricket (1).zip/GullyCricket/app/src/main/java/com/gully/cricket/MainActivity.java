package com.gully.cricket;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Hosts the offline scorer (assets/index.html) in a WebView. Matches are kept in WebView localStorage. */
public class MainActivity extends Activity {
    private static final int PICK_FILE = 42;
    private static final int VOICE = 43;
    private static final int PERM_LOC = 46;
    private WebView web;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private LocationManager lm;
    private LocationListener locListener;
    private Location best;
    private boolean locActive = false;
    private final Runnable locTimeout = this::finishLocation;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;
    private String pendingFile;
    private boolean pageReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);
        s.setSupportZoom(true);                    // pinch-zoom (v1.8.1)
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);           // gestures only, no +/- overlay
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                String u = req.getUrl().toString();
                if (u.startsWith("file:")) return false;
                openExternal(u);                       // mailto: and web links open in their own apps
                return true;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                pageReady = true;
                flushPendingFile();
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                boolean image = false;
                String[] accept = params.getAcceptTypes();
                if (accept != null) for (String a : accept) if (a != null && a.startsWith("image")) image = true;
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType(image ? "image/*" : "*/*");
                Intent i = pick;
                cameraUri = null;
                if (image) {
                    // team photo: offer the camera as well as the gallery
                    try {
                        File dir = new File(getCacheDir(), "shared");
                        if (!dir.exists()) dir.mkdirs();
                        File f = new File(dir, "cam_" + System.currentTimeMillis() + ".jpg");
                        cameraUri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".files", f);
                        Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                        cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        i = Intent.createChooser(pick, "Add team photo");
                        i.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
                    } catch (Exception e) {
                        cameraUri = null;
                        i = pick;
                    }
                }
                try {
                    startActivityForResult(i, PICK_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else {
            web.loadUrl("file:///android_asset/index.html");
            handleIncoming(getIntent());           // a match file opened from WhatsApp
        }
        Analytics.onAppStart(this);
        cleanShared();
    }

    /** Shared images, PDFs and full-size camera photos are temporary; drop ones older than a day. */
    private void cleanShared() {
        File[] old = new File(getCacheDir(), "shared").listFiles();
        if (old == null) return;
        long cutoff = System.currentTimeMillis() - 24L * 3600 * 1000;
        for (File f : old) if (f.lastModified() < cutoff) //noinspection ResultOfMethodCallIgnored
            f.delete();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE && fileCallback != null) {
            Uri[] res = null;
            if (resultCode == RESULT_OK) {
                if (data != null && (data.getData() != null || data.getClipData() != null)) {
                    res = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                } else if (cameraUri != null) {
                    res = new Uri[]{cameraUri};      // photo taken with the camera
                }
            }
            fileCallback.onReceiveValue(res);
            fileCallback = null;
            cameraUri = null;
        } else if (requestCode == VOICE && resultCode == RESULT_OK && data != null) {
            ArrayList<String> heard = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (heard != null && !heard.isEmpty()) {
                String json = new JSONArray(heard).toString();
                web.evaluateJavascript("window.onVoiceResult&&window.onVoiceResult(" + json + ")", null);
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }


    // ---------- GPS location for a match (saved only on the phone) ----------
    private void startLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, PERM_LOC);
            return;
        }
        lm = getSystemService(LocationManager.class);
        boolean gps = lm != null && lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        boolean net = lm != null && lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        if (!gps && !net) { jsLocError("off"); return; }
        stopLocation();
        best = null;
        locActive = true;
        locListener = new LocationListener() {
            @Override public void onLocationChanged(Location loc) {
                if (best == null || loc.getAccuracy() < best.getAccuracy()) best = loc;
                if (loc.getAccuracy() <= 25) finishLocation();   // good GPS fix
            }
            @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
            @Override public void onProviderEnabled(String provider) { }
            @Override public void onProviderDisabled(String provider) { }
        };
        try {
            if (gps) lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 0, locListener, Looper.getMainLooper());
            if (net) lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 500, 0, locListener, Looper.getMainLooper());
        } catch (SecurityException e) {
            locActive = false;
            jsLocError("denied");
            return;
        }
        ui.postDelayed(locTimeout, 20000);                      // take the best fix after 20 s
    }

    private void stopLocation() {
        if (lm != null && locListener != null) lm.removeUpdates(locListener);
        locListener = null;
    }

    private void finishLocation() {
        if (!locActive) return;
        locActive = false;
        ui.removeCallbacks(locTimeout);
        stopLocation();
        Location l = best;
        best = null;
        if (l == null) { jsLocError("timeout"); return; }
        final double lat = l.getLatitude(), lng = l.getLongitude();
        final float acc = l.getAccuracy();
        new Thread(() -> {
            String label = "";
            try {
                if (Geocoder.isPresent()) {
                    List<Address> a = new Geocoder(this, Locale.getDefault()).getFromLocation(lat, lng, 1);
                    if (a != null && !a.isEmpty()) {
                        Address ad = a.get(0);
                        String area = ad.getSubLocality() != null ? ad.getSubLocality() : ad.getFeatureName();
                        String city = ad.getLocality() != null ? ad.getLocality() : ad.getAdminArea();
                        label = (area != null ? area : "") + (area != null && city != null ? ", " : "") + (city != null ? city : "");
                    }
                }
            } catch (Exception ignored) { }   // place name is a nice-to-have; coordinates are enough
            try {
                JSONObject o = new JSONObject().put("lat", lat).put("lng", lng).put("acc", acc).put("label", label);
                runOnUiThread(() -> web.evaluateJavascript("window.onLocation&&window.onLocation(" + o + ")", null));
            } catch (Exception ignored) { }
        }, "geocode").start();
    }

    private void jsLocError(String code) {
        runOnUiThread(() -> web.evaluateJavascript("window.onLocationError&&window.onLocationError('" + code + "')", null));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != PERM_LOC) return;
        boolean ok = false;
        for (int g : grantResults) if (g == PackageManager.PERMISSION_GRANTED) ok = true;
        if (ok) startLocation();
        else jsLocError("denied");
    }

    @Override
    protected void onDestroy() {
        ui.removeCallbacksAndMessages(null);
        stopLocation();
        super.onDestroy();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncoming(intent);
    }

    /** A Gully Scorer match file (or backup) opened or shared into the app. */
    private void handleIncoming(Intent i) {
        if (i == null) return;
        Uri u = null;
        if (Intent.ACTION_VIEW.equals(i.getAction())) u = i.getData();
        else if (Intent.ACTION_SEND.equals(i.getAction())) u = i.getParcelableExtra(Intent.EXTRA_STREAM);
        if (u == null) return;
        final Uri uri = u;
        new Thread(() -> {
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) return;
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n, total = 0;
                while ((n = in.read(buf)) > 0) {
                    total += n;
                    if (total > 60 * 1024 * 1024) { toast("That file is too big"); return; }
                    out.write(buf, 0, n);
                }
                String text = out.toString("UTF-8");
                runOnUiThread(() -> { pendingFile = text; flushPendingFile(); });
            } catch (Exception e) {
                toast("Couldn't open that file");
            }
        }, "import").start();
    }

    private void flushPendingFile() {
        if (!pageReady || pendingFile == null) return;
        String t = pendingFile;
        pendingFile = null;
        web.evaluateJavascript("window.onIncomingFile&&window.onIncomingFile(" + JSONObject.quote(t) + ")", null);
    }

    private static String safeName(String name) {
        String n = name == null ? "file" : name.replaceAll("[^A-Za-z0-9._-]", "_");
        return n.isEmpty() ? "file" : n;
    }

    private File writeShared(String name, byte[] bytes) throws Exception {
        File dir = new File(getCacheDir(), "shared");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("no cache dir");
        File f = new File(dir, name);
        try (FileOutputStream o = new FileOutputStream(f)) { o.write(bytes); }
        return f;
    }

    private void shareFile(File f, String mime, String title) {
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".files", f);
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType(mime);
        i.putExtra(Intent.EXTRA_STREAM, uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, title));
    }

    private void openExternal(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            toast("No app found to open this");
        }
    }

    private void toast(String msg) {
        runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show());
    }

    /** Called from JavaScript as window.AndroidBridge.* */
    class Bridge {
        @JavascriptInterface
        public void startVoice() {
            runOnUiThread(() -> {
                Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN");
                i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
                i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say: four, six, dot, wide, no ball, out, undo");
                try {
                    startActivityForResult(i, VOICE);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Voice input not available on this phone", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void shareImage(String base64Png) {
            runOnUiThread(() -> {
                try {
                    File f = writeShared("gully-matchday.png", Base64.decode(base64Png, Base64.DEFAULT));
                    shareFile(f, "image/png", "Share scoreboard");
                } catch (Exception e) {
                    toast("Could not share image");
                }
            });
        }

        @JavascriptInterface
        public void shareText(String text, String fileName) {
            runOnUiThread(() -> {
                try {
                    if (fileName == null || fileName.isEmpty()) {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("text/plain");
                        i.putExtra(Intent.EXTRA_TEXT, text);
                        startActivity(Intent.createChooser(i, "Share"));
                    } else {
                        File f = writeShared(safeName(fileName), text.getBytes(StandardCharsets.UTF_8));
                        shareFile(f, "application/json", fileName.startsWith("Gully-Match") ? "Send match file" : "Save backup");
                    }
                } catch (Exception e) {
                    toast("Could not share");
                }
            });
        }

        /** Scorecard image/PDF and photos: base64 file → Android share sheet (WhatsApp etc.). */
        @JavascriptInterface
        public void shareFileB64(String b64, String name, String mime, String title) {
            runOnUiThread(() -> {
                try {
                    File f = writeShared(safeName(name), Base64.decode(b64, Base64.DEFAULT));
                    shareFile(f, mime == null ? "application/octet-stream" : mime, title == null ? "Share" : title);
                } catch (Exception e) {
                    toast("Could not share");
                }
            });
        }

        /** Help & support: opens the user's email app with the message ready to send. */
        @JavascriptInterface
        public void sendEmail(String to, String subject, String body) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
                i.putExtra(Intent.EXTRA_EMAIL, new String[]{to});
                i.putExtra(Intent.EXTRA_SUBJECT, subject);
                i.putExtra(Intent.EXTRA_TEXT, body);
                try {
                    startActivity(Intent.createChooser(i, "Send with"));
                } catch (ActivityNotFoundException e) {
                    toast("No email app found. Write to " + to);
                }
            });
        }

        @JavascriptInterface
        public void copyText(String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = getSystemService(ClipboardManager.class);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Gully Scorer", text));
            });
        }

        @JavascriptInterface
        public void getLocation() {
            runOnUiThread(MainActivity.this::startLocation);
        }

        @JavascriptInterface
        public void openLocationSettings() {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                } catch (Exception e) {
                    toast("Open Settings → Location and turn it on");
                }
            });
        }

        @JavascriptInterface
        public void openUrl(String url) {
            if (url != null && (url.startsWith("https://") || url.startsWith("mailto:"))) runOnUiThread(() -> openExternal(url));
        }

        @JavascriptInterface
        public void logEvent(String name) {
            Analytics.event(MainActivity.this, name);   // whitelisted names only; no payload
        }

        @JavascriptInterface
        public String appVersion() {
            try {
                PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
                long code = Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
                return pi.versionName + " (build " + code + ")";
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public String deviceInfo() {
            try {
                return new JSONObject().put("sdk", Build.VERSION.SDK_INT).put("model", Build.MANUFACTURER + " " + Build.MODEL).toString();
            } catch (Exception e) {
                return "{}";
            }
        }
    }
}
