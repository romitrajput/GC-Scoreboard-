#!/usr/bin/env bash
# Builds the APK and copies it to the project root as GullyScorer.apk
set -euo pipefail
cd "$(dirname "$0")"
[ -f local.properties ] || bash .devcontainer/setup-android.sh
chmod +x gradlew
./gradlew assembleDebug --no-daemon
cp app/build/outputs/apk/debug/app-debug.apk GullyScorer.apk
echo ""
echo "✅ Built: $(pwd)/GullyScorer.apk"
echo "   In Codespaces: right-click GullyScorer.apk in the Explorer → Download"
