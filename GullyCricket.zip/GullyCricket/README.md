# Gully Scorer — Android app (v1.2)

An offline scoring app for gully cricket. It tracks overs, balls, runs, wides, no-balls, free hits and wickets, and saves every match automatically. Each day gets its own matchday report, and the app keeps season stats across all your days.

**New in 1.2**
- 🏏 **Six rule is optional**: in match setup, choose whether a six is *6 runs*, *Out (0 runs)* or *6 runs + out*. On a free hit a six always counts as 6 runs.

**New in 1.1**
- 🤝 **Common player**: one player can bat and bowl for both teams.
- 📈 **Season stats**: all-time, 30-day and 7-day leaderboards, records, a count of Player of the Day awards, and player profiles.
- 🎤 **Voice scoring**: tap the mic and say "four", "chauka", "wide one", "no ball two", "bowled", "caught", "undo" and so on.

---

## Build the APK with GitHub Actions (recommended)

1. **Put the project in a GitHub repository.** Either push it from a codespace (`git add -A && git commit -m "Gully Scorer" && git push`), or upload the files on github.com with **Add file → Upload files**. Make sure `.github/workflows/build-apk.yml` is in the repository.
2. **Open the Actions tab.** If GitHub asks, click **"I understand my workflows, go ahead and enable them"**.
3. **Run the build.** It starts automatically on every push to `main`. You can also start it by hand: **Actions → Build APK → Run workflow → Run workflow**.
4. **Wait about 4–6 minutes** for a green ✔.
5. **Download the APK.** On the repository home page, click **Releases** (right side) → **Gully Scorer build N** → **GullyScorer.apk**. It's also on the run page under **Artifacts → GullyScorer-apk**, as a zip.
6. **Install it.** Open the downloaded APK on your Android phone, allow installs from this source when asked, and tap **Install**.

Every time you change the code and push, a new release is built. Install it over the old app; your saved matches are kept.

## Build in GitHub Codespaces (optional)
In the codespace terminal, run `bash .devcontainer/setup-android.sh` and then `./build-apk.sh`. When it finishes, right-click **GullyScorer.apk → Download**. The script picks Java 17 or 21 automatically.

## Alternative: Android Studio
Use **File → Open** → choose this folder → wait for Gradle sync → **Run ▶**, or **Build → Build APK(s)**.

## How it's built
- `app/src/main/assets/index.html` is the whole app: plain HTML, CSS and JS that works offline. To change the app, edit this file and rebuild.
- `MainActivity.java` shows that page in a WebView and stores the data in the WebView's local storage. It also connects the page to Android for these features:
  - **Voice**: uses Android's speech recogniser in Indian English (`en-IN`), so Hinglish words like *chauka*, *chhakka* and *ek* work.
  - **Share**: sends the day card image or the scorecard text through Android's share sheet (WhatsApp and others).
  - **Backup**: shares all your matches as a `.json` file. **Restore** opens the file picker.

## Voice commands
| Say | Records |
|---|---|
| dot · zero · no run | 0 |
| single · one · ek | 1 |
| two · double · do | 2 |
| three · teen | 3 |
| four · chauka · boundary | 4 |
| six · sixer · chhakka | 6 |
| wide · wide one (1 run ran) | Wide (+ runs ran) |
| no ball · no ball four | No-ball (+ runs off bat) |
| bye two · leg bye | Byes / leg byes |
| bowled | Wicket, recorded straight away |
| caught · run out · stumped · one tip one hand · out | Opens the wicket screen with that type picked so you can confirm |
| undo · swap strike | Undo last ball · swap batters |

Every voice entry shows a confirmation like 🎤 "chauka" → 4 runs. If it mishears, say "undo".
