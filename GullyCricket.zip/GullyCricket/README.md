# Gully Scorer — Android app (v1.2)

An offline scoring app for gully cricket. It tracks overs, balls, runs, wides, no-balls, free hits and wickets, and saves every match automatically. Each day gets its own matchday report, and the app keeps season stats across all your days.

**New in 1.2**
- 🏏 **Six rule is optional**: in match setup, choose whether a six is *6 runs*, *Out (0 runs)* or *6 runs + out*. On a free hit a six always counts as 6 runs.

**New in 1.1**
- 🤝 **Common player**: one player can bat and bowl for both teams.
- 📈 **Season stats**: all-time, 30-day and 7-day leaderboards, records, a count of Player of the Day awards, and player profiles.
- 🎤 **Voice scoring**: tap the mic and say "four", "chauka", "wide one", "no ball two", "bowled", "caught", "undo" and so on.

---

## Build the APK in GitHub Codespaces (no Android Studio needed)

### 1. Put the project on GitHub
1. Go to github.com → **New repository** and name it `gully-scorer`. Tick **Add a README file** and click **Create repository**.
2. On the repository page click **Code → Codespaces → Create codespace on main**. VS Code opens in your browser.
3. Drag **GullyCricket.zip** from your computer into the **Explorer** panel on the left.
4. Open the terminal (**Ctrl + `**) and unpack the project into the repository root:
   ```bash
   unzip -o GullyCricket.zip && cp -rT GullyCricket . && rm -rf GullyCricket GullyCricket.zip
   ```

### 2. Add the Android SDK packages
```bash
bash .devcontainer/setup-android.sh
```
This downloads Google's Android command-line tools. It then installs `platform-tools`, `platforms;android-34` and `build-tools;34.0.0`, accepts the licences, and writes `local.properties`. It takes about 2–4 minutes and only has to run once per codespace. Later codespaces made from this repository run it automatically through `.devcontainer/devcontainer.json`.

### 3. Build
```bash
./build-apk.sh
```
The first build downloads Gradle and the libraries, which takes about 3–5 minutes. When it finishes you'll have **`GullyScorer.apk`** in the project root.

### 4. Get it onto your phone
1. In the Explorer, right-click **GullyScorer.apk → Download**.
2. Send it to your phone (WhatsApp to yourself, Google Drive or USB) and tap it.
3. If Android warns about installing apps from outside the Play Store, allow it for that one app, then tap **Install**.

### 5. (Optional) Push to GitHub for automatic builds
You can skip this step. The APK from step 3 is all you need.
```bash
git add -A && git commit -m "Gully Scorer app" && git push
```
After you push, every later push also builds the APK on GitHub. Open the **Actions** tab → latest **Build APK** run → download **gully-scorer-apk**.

> **Preview in the browser:** run `python3 -m http.server 8080 -d app/src/main/assets`. Then open the **Ports** tab → port 8080 → 🌐. You can make the port public to open it on your phone.
>
> **Codespaces billing:** free accounts get a monthly allowance of free hours. Stop the codespace when you're finished (**Codespaces menu → Stop current codespace**).

---

## Alternative: Android Studio
Use **File → Open** → choose this folder → wait for Gradle sync → **Run ▶**, or **Build → Build APK(s)**.

## How it's built
- `app/src/main/assets/index.html` is the whole app: plain HTML, CSS and JS that works offline. To change the app, edit this file and rebuild.
- `MainActivity.java` shows that page in a WebView and stores the data in the WebView's local storage. It also connects the page to Android for these features:
  - **Voice**: uses Android's speech recogniser in Indian English (`en-IN`), so Hinglish words like *chauka*, *chhakka* and *ek* work.
  - **Share**: sends the day card image or the scorecard text through Android's share sheet (WhatsApp and others).
  - **Backup**: shares all your matches as a `.json` file. **Restore** opens the file picker.

## Voice commands
| Say | Records |
|---|---|
| dot · zero · no run | 0 |
| single · one · ek | 1 |
| two · double · do | 2 |
| three · teen | 3 |
| four · chauka · boundary | 4 |
| six · sixer · chhakka | 6 |
| wide · wide one (1 run ran) | Wide (+ runs ran) |
| no ball · no ball four | No-ball (+ runs off bat) |
| bye two · leg bye | Byes / leg byes |
| bowled | Wicket, recorded straight away |
| caught · run out · stumped · one tip one hand · out | Opens the wicket screen with that type picked so you can confirm |
| undo · swap strike | Undo last ball · swap batters |

Every voice entry shows a confirmation like 🎤 "chauka" → 4 runs. If it mishears, say "undo".
