package com.gully.cricket;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * Anonymous, aggregate usage analytics for the developer (install counts, active users, which
 * features get used). Privacy by design:
 *   - The only identifier is a random UUID made on this device. It is not linked to any account,
 *     name, phone number, email or Google/YouTube identity.
 *   - It NEVER sends player or team names, scores, match data, support messages, the user's
 *     email, or any location.
 *   - Event names are whitelisted here, so the web layer cannot smuggle personal data through.
 *   - Fully disabled unless a developer endpoint is baked in at build time (BuildConfig.ANALYTICS_ENDPOINT).
 *   - Best-effort and off the UI thread: failures are swallowed and never affect the app.
 */
final class Analytics {
    private Analytics() { }

    /** Only these event names are ever sent. Anything else from JS is ignored. */
    private static final Set<String> ALLOWED = new HashSet<>(Arrays.asList(
            "app_open", "match_started", "match_completed", "voice_used",
            "day_viewed", "season_viewed", "support_sent",
            "calendar_viewed", "location_added"   // a count only: coordinates and place names are never sent
    ));

    private static final String PREFS = "gully";
    private static final String K_ID = "an_id";
    private static final String K_DAY = "an_day";       // last day an "app_open" was counted
    private static final String K_FIRST = "an_first";    // first-seen flag → counts installs

    private static String endpoint() {
        String e = BuildConfig.ANALYTICS_ENDPOINT;
        return e == null ? "" : e.trim();
    }

    static boolean enabled() {
        return endpoint().startsWith("http");
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static String anonId(Context c) {
        SharedPreferences p = prefs(c);
        String id = p.getString(K_ID, null);
        if (id == null) {
            id = UUID.randomUUID().toString();   // random, not device- or account-derived
            p.edit().putString(K_ID, id).apply();
        }
        return id;
    }

    /** Call once per app start. Counts a new install the first time, and one active-user ping per day. */
    static void onAppStart(Context c) {
        if (!enabled()) return;
        SharedPreferences p = prefs(c);
        if (!p.getBoolean(K_FIRST, false)) {
            p.edit().putBoolean(K_FIRST, true).apply();
            send(c, "install", 0);
        }
        String today = new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new java.util.Date());
        if (!today.equals(p.getString(K_DAY, ""))) {
            p.edit().putString(K_DAY, today).apply();
            event(c, "app_open");            // at most once per calendar day → clean DAU counts
        }
    }

    /** Log a feature-usage event (whitelisted name only, no payload). */
    static void event(Context c, String name) {
        if (!enabled() || name == null || !ALLOWED.contains(name)) return;
        send(c, name, 0);
    }

    private static void send(Context c, String event, int ignored) {
        final String url = endpoint();
        final JSONObject body = new JSONObject();
        try {
            body.put("id", anonId(c));           // random install id
            body.put("event", event);
            body.put("app", BuildConfig.VERSION_NAME);
            body.put("build", BuildConfig.VERSION_CODE);
            body.put("os", Build.VERSION.SDK_INT);
            body.put("device", Build.MANUFACTURER + " " + Build.MODEL);
            body.put("country", Locale.getDefault().getCountry());   // coarse, from locale, not GPS
            body.put("lang", Locale.getDefault().getLanguage());
            body.put("ts", System.currentTimeMillis());
        } catch (Exception e) {
            return;
        }
        new Thread(() -> post(url, body.toString()), "analytics").start();
    }

    private static void post(String url, String json) {
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL(url).openConnection();
            con.setConnectTimeout(8000);
            con.setReadTimeout(8000);
            con.setRequestMethod("POST");
            con.setDoOutput(true);
            con.setRequestProperty("Content-Type", "application/json");
            try (OutputStream os = con.getOutputStream()) {
                os.write(json.getBytes(StandardCharsets.UTF_8));
            }
            con.getResponseCode();   // fire-and-forget
        } catch (Exception ignored) {
            // analytics must never crash or slow the app; drop silently
        } finally {
            if (con != null) con.disconnect();
        }
    }
}
