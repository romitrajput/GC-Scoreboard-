# Gully Scorer — Privacy Policy

_Last updated: November 2026_

Gully Scorer is a cricket scoring app. We keep your data on your phone and collect as little as possible.

## Stored only on your device
Match scores, teams, captains, player names, settings, and any match **location and notes** you add are stored **on your phone**. They are not uploaded to us and we cannot see them. Backups you create stay on your device unless you share them yourself.

## What leaves your phone, and only when you choose
- **Shared scorecards and day cards** go only to the app you pick (for example WhatsApp) when you tap Share.
- **Support messages** are sent from your own email app when you tap *Send to support*. You see the full message, including the app version and phone model if you leave that option on, before you send it.

## Anonymous usage analytics
To understand how many people use the app and which features are popular, the app may send **anonymous, aggregate** information:
- a random identifier created on your device (not linked to your name, email or any account),
- app version, Android version, device make/model, and your country/language from your phone's locale,
- the name of the feature used (for example "match started").

We **do not** collect your name, player or team names, scores, match data, match locations or notes, support messages, contacts, GPS location or your email address through analytics. If you add a location to a match, analytics only counts that a location was added. We use this only to improve the app. We do not sell it or share it with advertisers.

## Permissions
- **Internet:** for the anonymous analytics above and for looking up the area name of a GPS location. Scoring works fully offline.
- **Location:** only when you tap *Use GPS location* to save where a match was played. It is stored with that match on your phone and is not sent to us.
- **Microphone:** not requested by the app. Voice scoring uses your phone's own speech-recognition screen, which asks you itself.

## Children
The app is suitable for general audiences and does not target children.

## Contact
Questions about this policy or the app: **gs.usersupport@gmail.com**
