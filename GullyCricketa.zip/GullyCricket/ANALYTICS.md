# Developer analytics (private — do not ship this file's URL to users)

This is **your** dashboard, not part of the app. The app sends anonymous, aggregate usage pings so you can see how many people installed it, how many are active, and which features they use. There is **no analytics screen and no setting inside the app** — users never see any of this.

Analytics is **off by default**. It turns on only when you give the build an endpoint (below). No endpoint → the app sends nothing.

## What is and isn't collected

**Sent (anonymous):**
- A random install ID (a UUID generated on the device — not linked to any name, phone, email, or Google/YouTube account).
- App version and build number, Android version, device make/model.
- Country and language from the phone's locale (coarse — never GPS or precise location).
- An event name from a fixed list: `install`, `app_open` (once/day → active users), `match_started`, `match_completed`, `voice_used`, `day_viewed`, `season_viewed`, `support_sent`, `calendar_viewed`, `location_added`.

**Never sent:** player or team names, captains, scores, match data, support messages, the user's email, or match locations. `location_added` is only a count: no coordinates or place names. The event names are whitelisted in `Analytics.java`, so the app can't send anything else even by mistake.

## One compliance note (please read)
Google Play requires every app to declare data collection in its **Data safety** form and link a privacy policy, even for anonymous analytics. This doesn't add anything users tap, and doesn't change your numbers — it's just a short honest line ("collects anonymous app-usage and device info for analytics"). A ready privacy policy is in `PRIVACY.md`. Many regions (EU, and India's DPDP Act) legally expect this disclosure; skipping it is what gets apps pulled, not the analytics itself.

---

## Set up the free dashboard (Google Sheet, ~10 minutes)

You get a spreadsheet only you can open, filling itself with one row per event.

### 1. Make the sheet + script
1. Create a new Google Sheet (sheets.new). Rename the first tab to `events`.
2. In row 1, put these headers (A1 onward): `ts  id  event  app  build  os  device  country  lang  received`
3. **Extensions → Apps Script**. Delete the sample code and paste:

```javascript
const SHEET = 'events';
function doPost(e) {
  try {
    const d = JSON.parse(e.postData.contents);
    const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET);
    sh.appendRow([
      new Date(d.ts || Date.now()), d.id || '', d.event || '', d.app || '',
      d.build || '', d.os || '', d.device || '', d.country || '', d.lang || '', new Date()
    ]);
    return ContentService.createTextOutput('ok');
  } catch (err) {
    return ContentService.createTextOutput('err');
  }
}
```

4. **Deploy → New deployment → Web app**. Set **Execute as: Me**, **Who has access: Anyone**. Deploy, authorise, and copy the **Web app URL** (looks like `https://script.google.com/macros/s/AKfy…/exec`).

> "Anyone" means anyone with the long random URL can POST a row — it does **not** make your sheet public. Only you can open the spreadsheet. Keep the URL private.

### 2. Point the app at it
Choose one:
- **GitHub Actions (recommended):** in your repo, **Settings → Secrets and variables → Actions → New repository secret**. Name it `ANALYTICS_ENDPOINT`, value = the Web app URL. The next build bakes it in. No secret set = analytics stays off.
- **Local build:** create `app/analytics.properties` (already git-ignored) with one line:
  `endpoint=https://script.google.com/macros/s/AKfy…/exec`

Rebuild the APK. New installs will start appearing as rows.

### 3. Read your numbers
In the sheet, add a `dashboard` tab and use:
- **Total installs:** `=COUNTIF(events!C:C,"install")`
- **Active users today:** `=COUNTIFS(events!C:C,"app_open",events!A:A,">="&TODAY())`
- **Unique devices:** `=COUNTA(UNIQUE(events!B2:B))`
- **Feature usage:** `=COUNTIF(events!C:C,"voice_used")` (swap the event name)
- A pivot table on `event` (rows) × `app` version (columns) shows feature use by version.

## Scaling up later
If you outgrow a sheet (tens of thousands of rows), the same anonymous payload works with **Firebase Analytics**, **PostHog**, **Plausible**, or any endpoint that accepts a JSON POST — just change `ANALYTICS_ENDPOINT`. The app code doesn't change.

## Turning it off
Remove the `ANALYTICS_ENDPOINT` secret (or delete `app/analytics.properties`) and rebuild. The app goes back to sending nothing.
