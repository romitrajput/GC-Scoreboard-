# Gully Scorer — Android app (v1.6)

An offline scoring app for gully cricket. It tracks overs, balls, runs, wides, no-balls, free hits and wickets, and saves every match automatically. Each day gets its own matchday report, and the app keeps season stats across all your days.

**New in 1.6**
- 📅 **Month calendar** (Home → Calendar): a month grid where brighter days had more matches. It shows days played, matches, runs and wickets for the month, a matches-per-day chart, and the month's stars (MVP, most runs, most wickets, highest total). Tap a day for its totals, per-match averages, and a match-by-match table with score, overs, run rate, sixes and result.
- 📍 **Location & note** (optional) for each match: type the ground name, and tap **Use GPS location** to save the exact spot (the phone asks to turn location on if it's off). Add a note about the pitch, weather or rules. Saved grounds can be reused with one tap. You can also add or edit them later from a match's ⋯ menu, and open the spot in Maps.

**New in 1.5**
- 👥 **Captain & team table**: match setup is a two-column table. The captain goes in the first row and team members below. Teams are named after the captain (e.g. *Team Rahul vs Team Sohail*), and captains show as **(c)** on scorecards.
- ✎ **Change a batter**: tap a batter's name on the live screen.
  - If he hasn't faced a ball yet, swap him for anyone who hasn't batted (fixes a wrong pick).
  - If he has faced a ball, **retire him not out**. It isn't a wicket, and he can come back in later in the same innings with his runs kept.
- 💬 **Help & support**: users can send feedback, questions, problem reports and feature ideas to **gs.usersupport@gmail.com**. Their email app opens with the message, app version and phone model filled in.
- Removed: 3rd Umpire, video recording, live streaming, YouTube upload, and groups & game polls.

**Earlier versions**
- 1.4: version number at the bottom of Home, with a "What's new" list.
- 1.2: six rule option: 6 runs, Out (0 runs), or 6 runs + out.
- 1.1: common player, season stats & records, player profiles, voice scoring.
- 1.0: live scoring, wides/no-balls/free hit, wickets, undo, day scoreboard with awards & charts.

---

## Get the APK with GitHub Actions
1. Upload **GullyCricket.zip** to your repository with **Add file → Upload files** (same name, replacing the old one), then **Commit changes**.
2. **Actions → Build APK** runs automatically. Wait for the green ✔ (about 4–6 minutes).
3. On the repository's home page, open **Releases → Gully Scorer build N → GullyScorer.apk**, then open it on your phone and tap **Install**.

Each build has a higher version number and the same signing key, so it installs over the old app and your saved matches stay.

## Build in GitHub Codespaces (optional)
In the codespace terminal, run `bash .devcontainer/setup-android.sh` and then `./build-apk.sh`. When it finishes, right-click **GullyScorer.apk → Download**.

## Alternative: Android Studio
**File → Open** → choose this folder → wait for Gradle sync → **Run ▶**, or **Build → Build APK(s)**.

## How it's built
- `app/src/main/assets/index.html` is the whole app: plain HTML, CSS and JS that works offline. To change the app, edit this file and rebuild.
- `MainActivity.java` shows that page in a WebView and stores data in the WebView's local storage. It also connects the page to Android for:
  - **Voice**: Android's speech recogniser in Indian English (`en-IN`), so Hinglish words like *chauka*, *chhakka* and *ek* work.
  - **Share**: the day card image or scorecard text through Android's share sheet (WhatsApp and others).
  - **Backup**: all matches as a `.json` file. **Restore** opens the file picker.
  - **Support email**: opens the phone's email app addressed to gs.usersupport@gmail.com.
  - **GPS**: gets the match location when the user taps *Use GPS location*, and looks up the area name on the phone.

## Voice commands
| Say | Records |
|---|---|
| dot · zero · no run | 0 |
| single · one · ek | 1 |
| two · double · do | 2 |
| three · teen | 3 |
| four · chauka · boundary | 4 |
| six · sixer · chhakka | 6 |
| wide · wide one (1 run ran) | Wide (+ runs ran) |
| no ball · no ball four | No-ball (+ runs off bat) |
| bye two · leg bye | Byes / leg byes |
| bowled | Wicket, recorded straight away |
| caught · run out · stumped · one tip one hand · out | Opens the wicket screen with that type picked so you can confirm |
| undo · swap strike | Undo last ball · swap batters |

## Privacy & analytics
Match data, players, match locations and notes stay on the phone. `PRIVACY.md` is a ready privacy policy. The app can send **anonymous** usage counts to a dashboard only you (the developer) can see. It's off until you add an endpoint, and it never sends anything personal. Setup and the exact data are in `ANALYTICS.md`.
